<?php
/*
* Visual Composre Map File
*/
function rs_get_current_post_type() {

  $type = false;

  if( isset( $_GET['post'] ) ) {
    $id = $_GET['post'];
    $post = get_post( $id );

    if( is_object( $post ) && $post->post_type == 'portfolio' ) {
      $type = true;
    }

  } elseif ( isset( $_GET['post_type'] ) && $_GET['post_type'] == 'portfolio' ) {
    $type = true;
  }

  return $type;

}

include_once( RS_ROOT .'/composer/helpers.php' );
include_once( RS_ROOT .'/composer/params.php' );

if ( ! function_exists( 'is_plugin_active' ) ) {
  include_once( ABSPATH . 'wp-admin/includes/plugin.php' ); // Require plugin.php to use is_plugin_active() below
}

$vc_column_width_list = array(
  '1 column - 1/12'     => '1/12',
  '2 columns - 1/6'     => '1/6',
  '3 columns - 1/4'     => '1/4',
  '4 columns - 1/3'     => '1/3',
  '5 columns - 5/12'    => '5/12',
  '6 columns - 1/2'     => '1/2',
  '7 columns - 7/12'    => '7/12',
  '8 columns - 2/3'     => '2/3',
  '9 columns - 3/4'     => '3/4',
  '10 columns - 5/6'    => '5/6',
  '11 columns - 11/12'  => '11/12',
  '12 columns - 1/1'    => '1/1'
);

$vc_map_extra_id = array(
  'type'        => 'textfield',
  'heading'     => 'Extra ID',
  'param_name'  => 'id',
  'group'       => 'Extras'
);

$vc_map_extra_class = array(
  'type'        => 'textfield',
  'heading'     => 'Extra Class',
  'param_name'  => 'class',
  'group'       => 'Extras'
);


// ==========================================================================================
// IMAGE BLOCK
// ==========================================================================================
vc_map( array(
  'name'          => 'Image Block',
  'base'          => 'rs_image_block',
  'icon'          => 'fa fa-image',
  'description'   => 'Add image.',
  'params'        => array(
    array(
      'type'       => 'dropdown',
      'heading'    => 'Align',
      'param_name' => 'align',
      'value'      => array(
        'Select Alignment' => '',
        'Left'   => 'left',
        'Center' => 'center',
        'Center' => 'right',
      ),
    ),
    array(
      'type'        => 'attach_image',
      'heading'     => 'Image',
      'admin_label' => true,
      'param_name'  => 'image',
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Photo Credit',
      'param_name'  => 'photo_Credit',
    ),
    $vc_map_extra_id,
    $vc_map_extra_class,
  )
) );

// ==========================================================================================
// About Block
// ==========================================================================================
vc_map( array(
  'name'          => 'About Us Block',
  'base'          => 'rs_about_us_block',
  'icon'          => 'fa fa-image',
  'description'   => 'Add about us.',
  'params'        => array(
    array(
      'type'        => 'textfield',
      'heading'     => 'Heading',
      'holder'      => 'h4',
      'param_name'  => 'heading',
    ),
    array(
      'type'        => 'attach_image',
      'heading'     => 'Image',
      'admin_label' => true,
      'param_name'  => 'image',
    ),
    array(
      'type'        => 'textarea_html',
      'heading'     => 'Content',
      'param_name'  => 'content',
      'holder'      => 'div',
    ),
    array(
      'type'        => 'attach_image',
      'heading'     => 'Signature',
      'admin_label' => true,
      'param_name'  => 'signature',
    ),
    array(
      'type'        => 'vc_link',
      'heading'     => 'Link',
      'admin_label' => true,
      'param_name'  => 'link',
    ),
    $vc_map_extra_id,
    $vc_map_extra_class,
  )
) );

// ==========================================================================================
// Category Block
// ==========================================================================================
$category_block = array('Choose Category' => '') + rs_element_values( 'categories', array('taxonomy'    => 'category', 'hide_empty'  => false) );
vc_map( array(
  'name'          => 'Category Block',
  'base'          => 'rs_category_block',
  'icon'          => 'fa fa-image',
  'description'   => 'Add category block.',
  'params'        => array(
    array(
      'type'        => 'dropdown',
      'heading'     => 'Select Categories',
      'param_name'  => 'cats',
      'value'       => $category_block,
      'description' => 'You can choose specific categories.',
    ),
    array(
      'type'        => 'attach_image',
      'heading'     => 'Image',
      'admin_label' => true,
      'param_name'  => 'image',
    ),
    $vc_map_extra_id,
    $vc_map_extra_class,
  )
) );

// ==========================================================================================
// Progress Bar Rating
// ==========================================================================================
vc_map( array(
  'name'                    => 'Progress Bar Rating',
  'base'                    => 'rs_progress_bar_rating',
  'icon'                    => 'fa fa-bank',
  'as_parent'               => array('only' => 'rs_progress_bar_rating_item'),
  'show_settings_on_create' => true,
  'js_view'                 => 'VcColumnView',
  'content_element'         => true,
  'description'             => 'Create a rating.',
  'params'  => array(
    array(
      'type'        => 'textarea',
      'heading'     => 'Summary',
      'param_name'  => 'summary_text',
      'holder'      => 'div',
    ),
    $vc_map_extra_id,
    $vc_map_extra_class,
  ),

) );

vc_map( array(
  'name'        => 'Progress Bar Rating Item',
  'base'        => 'rs_progress_bar_rating_item',
  'icon'        => 'fa fa-bank',
  'description' => 'Add rating item.',
  'as_child'    => array('only' => 'rs_progress_bar_rating'),
  'params'  => array(
    array(
      'type'        => 'textfield',
      'heading'     => 'Rating Label',
      'param_name'  => 'rating_label',
      'holder'      => 'h3',
      'value'       => ''
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Rating Number',
      'param_name'  => 'rating_number',
      'value'       => '',
      'description' => 'Add rating value out of 10. for e.g 4, 7.5, default is 0'
    ),
  )

) );

// ==========================================================================================
// IMAGE VIDEO BLOCK
// ==========================================================================================
vc_map( array(
  'name'          => 'Video Block',
  'base'          => 'rs_video_block',
  'icon'          => 'fa fa-image',
  'description'   => 'Add video.',
  'params'        => array(
    array(
      'type'        => 'textfield',
      'heading'     => 'Video URL',
      'admin_label' => true,
      'param_name'  => 'video_url',
      'description' => 'https://player.vimeo.com/video/171807697?color=f561af&badge=0'
    ),
    $vc_map_extra_id,
    $vc_map_extra_class,
  )
) );

// ==========================================================================================
// Featured Video With Post
// ==========================================================================================
vc_map( array(
  'name'          => 'Featured Video With Post',
  'base'          => 'rs_featured_video_with_post',
  'icon'          => 'fa fa-image',
  'description'   => 'Add video with post.',
  'params'        => array(
    array(
      'type'        => 'dropdown',
      'admin_label' => true,
      'heading'     => 'Style',
      'param_name'  => 'style',
      'value'       => array(
        'Style 1' => 'style1',
        'Style 2' => 'style2',
      ),
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Heading',
      'holder'      => 'h3',
      'param_name'  => 'heading',
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Video URL',
      'admin_label' => true,
      'param_name'  => 'video_url',
      'description' => 'https://player.vimeo.com/video/171807697?color=f561af&badge=0'
    ),
    array(
      'type'        => 'vc_efa_chosen',
      'heading'     => 'Select Categories',
      'param_name'  => 'cats',
      'placeholder' => 'Select category',
      'value'       => rs_element_values( 'categories', array(
        'sort_order'  => 'ASC',
        'taxonomy'    => 'category',
        'hide_empty'  => false,
      ) ),
      'std'         => '',
      'description' => 'You can choose specific categories for blog, default is all categories.',
    ),
    array(
      'type'        => 'dropdown',
      'admin_label' => true,
      'heading'     => 'Order by',
      'param_name'  => 'orderby',
      'value'       => array(
        'ID'            => 'ID',
        'Author'        => 'author',
        'Post Title'    => 'title',
        'Date'          => 'date',
        'Last Modified' => 'modified',
        'Random Order'  => 'rand',
        'Comment Count' => 'comment_count',
        'Menu Order'    => 'menu_order',
      ),
    ),
    $vc_map_extra_id,
    $vc_map_extra_class,
  )
) );

// ==========================================================================================
// Post Movie
// ==========================================================================================
vc_map( array(
  'name'          => 'Post Movie',
  'base'          => 'rs_post_movie',
  'icon'          => 'fa fa-image',
  'description'   => 'Add post movie.',
  'params'        => array(
    array(
      'type'        => 'vc_efa_chosen',
      'heading'     => 'Select Categories',
      'param_name'  => 'cats',
      'placeholder' => 'Select category',
      'value'       => rs_element_values( 'categories', array(
        'sort_order'  => 'ASC',
        'taxonomy'    => 'category',
        'hide_empty'  => false,
      ) ),
      'std'         => '',
      'description' => 'You can choose specific categories for post movie, default is all categories.',
    ),
    array(
      'type'        => 'dropdown',
      'admin_label' => true,
      'heading'     => 'Order by',
      'param_name'  => 'orderby',
      'value'       => array(
        'ID'            => 'ID',
        'Author'        => 'author',
        'Post Title'    => 'title',
        'Date'          => 'date',
        'Last Modified' => 'modified',
        'Random Order'  => 'rand',
        'Comment Count' => 'comment_count',
        'Menu Order'    => 'menu_order',
      ),
    ),
    $vc_map_extra_id,
    $vc_map_extra_class,
  )
) );

// ==========================================================================================
// Sound Cloud Embed
// ==========================================================================================
vc_map( array(
  'name'          => 'Sound Cloud Embed',
  'base'          => 'rs_sound_cloud_embed',
  'icon'          => 'fa fa-image',
  'description'   => 'Add sound cloud embed.',
  'params'        => array(
    array(
      'type'        => 'textfield',
      'heading'     => 'Sound Cloud URL',
      'admin_label' => true,
      'param_name'  => 'sound_cloud_url',
      'description' => 'https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/tracks/272473515&amp;color=ff5500&amp;auto_play=false&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false'
    ),
    $vc_map_extra_id,
    $vc_map_extra_class,
  )
) );

// ==========================================================================================
// Featured Blog News
// ==========================================================================================
vc_map( array(
  'name'            => 'Featured Blog News',
  'base'            => 'rs_featured_blog',
  'icon'            => 'fa fa-briefcase',
  'description'     => 'Create a featured news post.',
  'params'          => array(
    array(
      'type'        => 'dropdown',
      'admin_label' => true,
      'heading'     => 'Style',
      'param_name'  => 'style',
      'value'       => array(
        'Style 1' => 'style1',
        'Style 2' => 'style2',
        'Style 3' => 'style3',
      ),
    ),
    array(
      'type'        => 'vc_efa_chosen',
      'heading'     => 'Select Categories',
      'param_name'  => 'cats',
      'placeholder' => 'Select category',
      'value'       => rs_element_values( 'categories', array(
        'sort_order'  => 'ASC',
        'taxonomy'    => 'category',
        'hide_empty'  => false,
      ) ),
      'std'         => '',
      'description' => 'You can choose specific categories for blog, default is all categories.',
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Post Per Page',
      'param_name'  => 'post_per_page',
      'description' => 'Post Per Page',
    ),
    array(
      'type'        => 'dropdown',
      'admin_label' => true,
      'heading'     => 'Order by',
      'param_name'  => 'orderby',
      'value'       => array(
        'ID'            => 'ID',
        'Author'        => 'author',
        'Post Title'    => 'title',
        'Date'          => 'date',
        'Last Modified' => 'modified',
        'Random Order'  => 'rand',
        'Comment Count' => 'comment_count',
        'Menu Order'    => 'menu_order',
      ),
    ),
    // Extras
    $vc_map_extra_id,
    $vc_map_extra_class,
  ),
) );

// ==========================================================================================
// Recent News
// ==========================================================================================
vc_map( array(
  'name'            => 'Recent News',
  'base'            => 'rs_recent_news',
  'icon'            => 'fa fa-briefcase',
  'description'     => 'Create a recent news post.',
  'params'          => array(
    array(
      'type'        => 'vc_efa_chosen',
      'heading'     => 'Select Categories',
      'param_name'  => 'cats',
      'placeholder' => 'Select category',
      'value'       => rs_element_values( 'categories', array(
        'sort_order'  => 'ASC',
        'taxonomy'    => 'category',
        'hide_empty'  => false,
      ) ),
      'std'         => '',
      'description' => 'You can choose specific categories for blog, default is all categories.',
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Post Per Page',
      'param_name'  => 'post_per_page',
      'description' => 'Post Per Page',
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Excerpt Length',
      'param_name'  => 'excerpt_length',
      'description' => 'Post Per Page',
    ),
    array(
      'type'        => 'dropdown',
      'admin_label' => true,
      'heading'     => 'Order by',
      'param_name'  => 'orderby',
      'value'       => array(
        'ID'            => 'ID',
        'Author'        => 'author',
        'Post Title'    => 'title',
        'Date'          => 'date',
        'Last Modified' => 'modified',
        'Random Order'  => 'rand',
        'Comment Count' => 'comment_count',
        'Menu Order'    => 'menu_order',
      ),
    ),
    // Extras
    $vc_map_extra_id,
    $vc_map_extra_class,
  ),
) );

// ==========================================================================================
// Weekly Blog Posts
// ==========================================================================================
vc_map( array(
  'name'            => 'Weekly Top Blog News',
  'base'            => 'rs_weekly_blog',
  'icon'            => 'fa fa-briefcase',
  'description'     => 'Create a weekly top post.',
  'params'          => array(
    array(
      'type'        => 'vc_efa_chosen',
      'heading'     => 'Select Categories',
      'param_name'  => 'cats',
      'placeholder' => 'Select category',
      'value'       => rs_element_values( 'categories', array(
        'sort_order'  => 'ASC',
        'taxonomy'    => 'category',
        'hide_empty'  => false,
      ) ),
      'std'         => '',
      'description' => 'You can choose specific categories for blog, default is all categories.',
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Post Per Page',
      'param_name'  => 'post_per_page',
      'description' => 'Post Per Page',
    ),
    array(
      'type'        => 'dropdown',
      'admin_label' => true,
      'heading'     => 'Order by',
      'param_name'  => 'orderby',
      'value'       => array(
        'ID'            => 'ID',
        'Author'        => 'author',
        'Post Title'    => 'title',
        'Date'          => 'date',
        'Last Modified' => 'modified',
        'Random Order'  => 'rand',
        'Comment Count' => 'comment_count',
        'Menu Order'    => 'menu_order',
      ),
    ),
    // Extras
    $vc_map_extra_id,
    $vc_map_extra_class,
  ),
) );

// ==========================================================================================
// Hand Picked Blog
// ==========================================================================================
vc_map( array(
  'name'            => 'Hand Picked Blog',
  'base'            => 'rs_hand_picked_blog',
  'icon'            => 'fa fa-briefcase',
  'description'     => 'Create a hand picked post.',
  'params'          => array(
    array(
      'type'        => 'dropdown',
      'admin_label' => true,
      'heading'     => 'Style',
      'param_name'  => 'style',
      'value'       => array(
        'Style 1' => 'style1',
        'Style 2' => 'style2',
        'Style 3' => 'style3',
      ),
    ),
    array(
      'type'        => 'vc_efa_chosen',
      'heading'     => 'Select Categories',
      'param_name'  => 'cats',
      'placeholder' => 'Select category',
      'value'       => rs_element_values( 'categories', array(
        'sort_order'  => 'ASC',
        'taxonomy'    => 'category',
        'hide_empty'  => false,
      ) ),
      'std'         => '',
      'description' => 'You can choose specific categories for blog, default is all categories.',
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Post Per Page',
      'param_name'  => 'post_per_page',
      'description' => 'Post Per Page',
    ),
    array(
      'type'        => 'dropdown',
      'admin_label' => true,
      'heading'     => 'Order by',
      'param_name'  => 'orderby',
      'value'       => array(
        'ID'            => 'ID',
        'Author'        => 'author',
        'Post Title'    => 'title',
        'Date'          => 'date',
        'Last Modified' => 'modified',
        'Random Order'  => 'rand',
        'Comment Count' => 'comment_count',
        'Menu Order'    => 'menu_order',
      ),
    ),
    // Extras
    $vc_map_extra_id,
    $vc_map_extra_class,
  ),
) );

// ==========================================================================================
// Post Grid Series
// ==========================================================================================
vc_map( array(
  'name'            => 'Post Grid Series',
  'base'            => 'rs_post_grid_series',
  'icon'            => 'fa fa-briefcase',
  'description'     => 'Create a post grid series.',
  'params'          => array(
    array(
      'type'        => 'vc_efa_chosen',
      'heading'     => 'Select Categories',
      'param_name'  => 'cats',
      'placeholder' => 'Select category',
      'value'       => rs_element_values( 'categories', array(
        'sort_order'  => 'ASC',
        'taxonomy'    => 'category',
        'hide_empty'  => false,
      ) ),
      'std'         => '',
      'description' => 'You can choose specific categories for blog, default is all categories.',
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Post Per Page',
      'param_name'  => 'post_per_page',
      'description' => 'Post Per Page',
    ),
    array(
      'type'        => 'dropdown',
      'admin_label' => true,
      'heading'     => 'Order by',
      'param_name'  => 'orderby',
      'value'       => array(
        'ID'            => 'ID',
        'Author'        => 'author',
        'Post Title'    => 'title',
        'Date'          => 'date',
        'Last Modified' => 'modified',
        'Random Order'  => 'rand',
        'Comment Count' => 'comment_count',
        'Menu Order'    => 'menu_order',
      ),
    ),
    // Extras
    $vc_map_extra_id,
    $vc_map_extra_class,
  ),
) );

// ==========================================================================================
// SPECIAL TEXT
// ==========================================================================================
vc_map( array(
  'name'          => 'Special Text',
  'base'          => 'rs_special_text',
  'icon'          => 'fa fa-tint',
  'description'   => 'Create special text.',
  'params'        => array(
    array(
      'type'        => 'dropdown',
      'heading'     => 'Font',
      'param_name'  => 'font',
      'admin_label' => true,
      'value'       => array_flip(rs_get_font_choices(true)),
    ),
    array(
      'type'        => 'dropdown',
      'heading'     => 'Tag Name',
      'param_name'  => 'tag',
      'value'       => array(
        'H1'  => 'h1',
        'H2'  => 'h2',
        'H3'  => 'h3',
        'H4'  => 'h4',
        'H5'  => 'h5',
        'H6'  => 'h6',
        'div' => 'div',
      ),
    ),
    array(
      'type'        => 'textarea_html',
      'heading'     => 'Content',
      'param_name'  => 'content',
      'holder'      => 'div',
    ),
    array(
      'type'        => 'dropdown',
      'heading'     => 'Align',
      'param_name'  => 'align',
      'value'       => array(
        'Select Align' => '',
        'Left'   => 'left',
        'Center' => 'center',
        'Right'  => 'right',
      ),
      'group'       => 'Custom Font Properties'
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Font Size',
      'param_name'  => 'font_size',
      'description' => 'Enter the size in pixel e.g 45px',
      'group'       => 'Custom Font Properties'
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Line Height',
      'param_name'  => 'line_height',
      'group'       => 'Custom Font Properties'
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Letter Spacing',
      'param_name'  => 'letter_spacing',
      'description' => 'Enter the size in pixel e.g 1px',
      'group'       => 'Custom Font Properties'
    ),
    array(
      'type'        => 'colorpicker',
      'heading'     => 'Font Color',
      'param_name'  => 'font_color',
      'group'       => 'Custom Font Properties'
    ),
    array(
      'type'        => 'dropdown',
      'heading'     => 'Font Weight',
      'param_name'  => 'font_weight',
      'value'       => array(
        'Light'      => '300',
        'Normal'     => '400',
        'Bold'       => '600',
        'Bold'       => '700',
        'Extra Bold' => '800',
      ),
      'group'       => 'Custom Font Properties'
    ),
    array(
      'type'        => 'dropdown',
      'heading'     => 'Font Style',
      'param_name'  => 'font_style',
      'value'       => array(
        'Normal' => 'normal',
        'Italic' => 'italic',
      ),
      'group'       => 'Custom Font Properties'
    ),
    array(
      'type'        => 'dropdown',
      'heading'     => 'Text Transform',
      'param_name'  => 'transform',
      'value'       => array(
        'Select Transform' => '',
        'Uppercase'        => 'uppercase',
        'Lowercase'        => 'lowercase',
      ),
      'group'       => 'Custom Font Properties'
    ),

    array(
      'type'        => 'textfield',
      'heading'     => 'Margin Top',
      'param_name'  => 'margin_top',
      'description' => 'Enter the size in pixel e.g 45px',
      'group'       => 'Custom Margin Properties'
    ),

    array(
      'type'        => 'textfield',
      'heading'     => 'Margin Bottom',
      'param_name'  => 'margin_bottom',
      'description' => 'Enter the size in pixel e.g 45px',
      'group'       => 'Custom Margin Properties'
    ),
    array(
      'type' => 'css_editor',
      'heading' => esc_html__( 'CSS box', 'js_composer' ),
      'param_name' => 'css',
      'group' => esc_html__( 'Design Options', 'js_composer' )
    ),
    // Extras
    $vc_map_extra_id,
    $vc_map_extra_class,

  )
) );

// ==========================================================================================
// Space
// ==========================================================================================
vc_map( array(
  'name'          => 'Space',
  'base'          => 'rs_space',
  'icon'          => 'fa fa fa-arrows-v',
  'description'   => 'Add space.',
  'params'        => array(
    array(
      'type'        => 'dropdown',
      'heading'     => 'Height',
      'admin_label' => true,
      'param_name'  => 'lg_device',
      'group'       => 'Large Device',
      'value'       => rs_get_space_array(),
      'description' => 'All values are in px'
    ),
    array(
      'type'        => 'dropdown',
      'heading'     => 'Height',
      'admin_label' => true,
      'param_name'  => 'md_device',
      'group'       => 'Medium Device',
      'value'       => rs_get_space_array(),
      'description' => 'All values are in px'
    ),
    array(
      'type'        => 'dropdown',
      'heading'     => 'Height',
      'admin_label' => true,
      'param_name'  => 'sm_device',
      'group'       => 'Small Device',
      'value'       => rs_get_space_array(),
      'description' => 'All values are in px'
    ),
    array(
      'type'        => 'dropdown',
      'heading'     => 'Height',
      'admin_label' => true,
      'param_name'  => 'xs_device',
      'group'       => 'Extra Small Device',
      'value'       => rs_get_space_array(),
      'description' => 'All values are in px'
    ),

    $vc_map_extra_id,
    $vc_map_extra_class,
  )
) );

// ==========================================================================================
// Blockquote
// ==========================================================================================
vc_map( array(
  'name'          => 'Blockquote',
  'base'          => 'rs_blockquote',
  'icon'          => 'fa fa-quote-left',
  'description'   => 'Add blockquote.',
  'params'        => array(
    array(
      'type'        => 'textarea_html',
      'heading'     => 'Content',
      'holder'      => 'div',
      'param_name'  => 'content',
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Cite',
      'admin_label' => true,
      'param_name'  => 'cite',
    ),

    $vc_map_extra_id,
    $vc_map_extra_class,
  )
) );

// ==========================================================================================
// Video banner
// ==========================================================================================
vc_map( array(
  'name'          => 'Video Banner',
  'base'          => 'rs_video_banner',
  'icon'          => 'fa fa-video-camera',
  'description'   => 'Add video banner.',
  'params'        => array(
    array(
      'type'        => 'attach_image',
      'heading'     => 'Image',
      'admin_label' => true,
      'param_name'  => 'image',
    ),
    array(
      'type'        => 'vc_link',
      'heading'     => 'Link',
      'admin_label' => true,
      'param_name'  => 'link',
    ),

    $vc_map_extra_id,
    $vc_map_extra_class,
  )
) );

// ==========================================================================================
// Section Title // xxx
// ==========================================================================================
vc_map( array(
  'name'          => 'Section Heading',
  'base'          => 'rs_section_heading',
  'icon'          => 'fa fa-text-width',
  'description'   => 'Add section heading.',
  'params'        => array(
    array(
      'type'        => 'textfield',
      'heading'     => 'Heading',
      'holder'      => 'h1',
      'param_name'  => 'heading',
    ),
    $vc_map_extra_id,
    $vc_map_extra_class,
  )
) );


// ==========================================================================================
// Gallery Showcase
// ==========================================================================================
vc_map( array(
  'name'            => 'Gallery Showcase',
  'base'            => 'rs_gallery_showcase',
  'icon'            => 'fa fa-paw',
  'description'     => 'Add gallery showcase item.',
  'params'          => array(
    array(
      'type'        => 'attach_images',
      'heading'     => 'Image',
      'admin_label' => true,
      'param_name'  => 'images',
      'description' => 'Multiple images are supported.'
    ),

    // Extras
    $vc_map_extra_id,
    $vc_map_extra_class,

  )

) );

// ==========================================================================================
// Gif Showcase
// ==========================================================================================
vc_map( array(
  'name'            => 'Gif Showcase',
  'base'            => 'rs_gif_showcase',
  'icon'            => 'fa fa-paw',
  'description'     => 'Add gif showcase item.',
  'params'          => array(
    array(
      'type'        => 'textfield',
      'heading'     => 'URL',
      'admin_label' => true,
      'param_name'  => 'gif_url',
      'description' => 'http://giphy.com/embed/yrSgmpUSWgRyg'
    ),

    // Extras
    $vc_map_extra_id,
    $vc_map_extra_class,

  )

) );


// ==========================================================================================
// VC COLUMN TEXT
// ==========================================================================================
vc_map( array(
  'name'          => 'Text Block',
  'base'          => 'vc_column_text',
  'icon'          => 'fa fa-text-width',
  'description'   => 'A block of text with WYSIWYG editor',
  'params'        => array(
    array(
      'type'        => 'dropdown',
      'heading'     => 'Wrap With Classes ?',
      'param_name'  => 'wrap_with_class',
      'value'       => array(
        'Yes' => 'yes',
        'No'  => 'no',
      ),
    ),
    array(
      'holder'     => 'div',
      'type'       => 'textarea_html',
      'heading'    => 'Text',
      'param_name' => 'content',
      'value'      => '<p>I am text block. Click edit button to change this text.</p>',
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Font Size',
      'param_name'  => 'font_size',
      'description' => 'Enter the size in pixel e.g 45px',
      'group'       => 'Custom Font Properties'
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Line Height',
      'param_name'  => 'line_height',
      'group'       => 'Custom Font Properties'
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Letter Spacing',
      'param_name'  => 'letter_spacing',
      'description' => 'Enter the size in pixel e.g 1px',
      'group'       => 'Custom Font Properties'
    ),
    array(
      'type'        => 'colorpicker',
      'heading'     => 'Font Color',
      'param_name'  => 'font_color',
      'group'       => 'Custom Font Properties'
    ),

    $vc_map_extra_id,
    $vc_map_extra_class,
  )
) );

// ==========================================================================================
// BUTTONS
// ==========================================================================================
vc_map( array(
  'name'          => 'Buttons',
  'base'          => 'rs_button',
  'icon'          => 'fa fa-square',
  'description'   => 'Create a classy button.',
  'params'        => array(
    array(
      'type'        => 'dropdown',
      'heading'     => 'Size',
      'param_name'  => 'size',
      'value'       => array(
        'Very Small' => 'v-small',
        'Small'      => 'small',
        'Medium'     => 'medium',
        'Large'      => 'large',
        'Very Large' => 'v-large'
      ),
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Button Text',
      'param_name'  => 'btn_text',
      'admin_label' => true,
    ),
    array(
      'type'        => 'vc_link',
      'heading'     => 'Button Link',
      'param_name'  => 'btn_link',
    ),
    array(
      'type'        => 'colorpicker',
      'heading'     => 'Background Color',
      'param_name'  => 'bg_color',
      'group'       => 'Custom Properties'
    ),
    array(
      'type'        => 'colorpicker',
      'heading'     => 'Background Hover Color',
      'param_name'  => 'bg_hover_color',
      'group'       => 'Custom Properties'
    ),
    array(
      'type'        => 'colorpicker',
      'heading'     => 'Text Color',
      'param_name'  => 'text_color',
      'group'       => 'Custom Properties'
    ),
    array(
      'type'        => 'colorpicker',
      'heading'     => 'Text Hover Color',
      'param_name'  => 'text_hover_color',
      'group'       => 'Custom Properties'
    ),
    array(
      'type'        => 'textfield',
      'heading'     => 'Font Size',
      'param_name'  => 'font_size',
      'description' => 'for e.g 14px',
      'group'       => 'Custom Properties'
    ),

    // Extras
    $vc_map_extra_id,
    $vc_map_extra_class,

  )
) );


// ==========================================================================================
// WP Post Gallery Widget 
// ==========================================================================================
vc_map( array(
  'name'            => 'WP Post Gallery/Video',
  'base'            => 'rs_wp_post_gallery_video',
  'icon'            => 'icon-wpb-wp',
  'description'     => 'Create post gallery/video.',
  'params'          => array(
    array(
      'type'        => 'textfield',
      'heading'     => 'Widget Title',
      'param_name'  => 'widget_title',
      'holder'      => 'h3',
      'description' => 'Widget Title',
    ),
    array(
      'type'        => 'vc_efa_chosen',
      'heading'     => 'Select Post Name',
      'param_name'  => 'post_id',
      'admin_label' => true,
      'placeholder' => 'Select post',
      'value'       => rs_element_values( 'post', array(
        'post_type'  => 'post',
      ) ),
      'std'         => '',
      'description' => 'You can choose specific post name NOTE select only 1.',
    ),
  ),
) );

class WPBakeryShortCode_RS_Progress_Bar_Rating   extends WPBakeryShortCodesContainer {}
class WPBakeryShortCode_RS_Progress_Bar_Rating_Item  extends WPBakeryShortCode {}

class RS_WPBakeryShortCodesContainer extends WPBakeryShortCodesContainer {
  public function contentAdmin( $atts, $content = null ) {
      $width = $el_class = '';
      extract( shortcode_atts( $this->predefined_atts, $atts ) );
      $label_class = ( isset( $this->settings['label_class'] ) ) ? $this->settings['label_class'] : 'info';
      $output  = '';

      $column_controls = $this->getColumnControls( $this->settings( 'controls' ) );
      $column_controls_bottom = $this->getColumnControls( 'add', 'bottom-controls' );
      for ( $i = 0; $i < count( $width ); $i ++ ) {
        $output .= '<div ' . $this->mainHtmlBlockParams( $width, $i ) . '>';
        $output .= '<div class="rs-container-title"><span class="rs-label rs-label-'. $label_class .'">'. $this->settings['name'] .'</span></div>'; // ADDED THIS LINE
        $output .= $column_controls;
        $output .= '<div class="wpb_element_wrapper">';
        $output .= '<div ' . $this->containerHtmlBlockParams( $width, $i ) . '>';
        $output .= do_shortcode( shortcode_unautop( $content ) );
        $output .= '</div>';
        if ( isset( $this->settings['params'] ) ) {
          $inner = '';
          foreach ( $this->settings['params'] as $param ) {
            $param_value = isset( $$param['param_name'] ) ? $$param['param_name'] : '';
            if ( is_array( $param_value ) ) {
              // Get first element from the array
              reset( $param_value );
              $first_key = key( $param_value );
              $param_value = $param_value[$first_key];
            }
            $inner .= $this->singleParamHtmlHolder( $param, $param_value );
          }
          $output .= $inner;
        }
        $output .= '</div>';
        $output .= $column_controls_bottom;
        $output .= '</div>';
      }
      return $output;
  }
}

add_action( 'admin_init', 'vc_remove_elements', 10);
function vc_remove_elements( $e = array() ) {

  if ( !empty( $e ) ) {
    foreach ( $e as $key => $r_this ) {
      vc_remove_element( 'vc_'.$r_this );
    }
  }
}

$s_elemets = array( 'btn', 'toggle', 'raw_html', 'round_chart', 'line_chart', 'cta', 'tta_pageable', 'tta_tour', 'tta_accordion', 'icon', 'masonry_media_grid', 'masonry_grid', 'basic_grid', 'media_grid', 'custom_heading', 'empty_space', 'clients', 'widget_sidebar', 'images_carousel', 'carousel', 'tour', 'gallery', 'posts_slider', 'posts_grid', 'teaser_grid', 'separator', 'text_separator', 'message', 'facebook', 'tweetmeme', 'googleplus', 'pinterest', 'single_image', 'button', 'button2', 'cta_button', 'cta_button2', 'video', 'gmaps', 'flickr', 'progress_bar', 'raw_js', 'pie', 'wp_meta', 'wp_recentcomments', 'wp_text', 'wp_calendar', 'wp_pages', 'wp_custommenu', 'wp_posts', 'wp_links', 'wp_categories', 'wp_archives', 'wp_rss' );
vc_remove_element('client', 'testimonial', 'contact-form-7');
vc_remove_elements( $s_elemets );