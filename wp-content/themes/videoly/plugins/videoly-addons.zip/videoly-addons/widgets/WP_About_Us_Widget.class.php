<?php
/**
 * Contact Form widget
 *
 * @package videoly
 */

class videoly_WP_About_Us_Widget extends WP_Widget
{
    function __construct()
    {
        $widget_ops = array('classname' => 'widget_about_us_entries', 'description' => __( 'Add About Us Block', 'videoly-addons' ) );
        parent::__construct('about-us', __( '- videoly: About Us', 'videoly-addons' ), $widget_ops);

        $this-> alt_option_name = 'widget_about_us_entries';

        add_action( 'save_post',    array(&$this, 'flush_widget_cache') );
        add_action( 'deleted_post', array(&$this, 'flush_widget_cache') );
        add_action( 'switch_theme', array(&$this, 'flush_widget_cache') );
    }

    function widget($args, $instance)
    {
        global $post;

        $cache = wp_cache_get('widget_about_us_entries', 'widget');

        if ( !is_array($cache) )
        {
            $cache = array();
        }
        if ( ! isset( $args['widget_id'] ) )
        {
          $args['widget_id'] = $this->id;
        }

        if ( isset( $cache[ $args['widget_id'] ] ) )
        {
          echo $cache[ $args['widget_id'] ];
          return;
        }

        ob_start();
        extract($args);
        echo $before_widget;

        $title = apply_filters('widget_title', $instance['title'], $instance, $this->id_base); ?>

        <div class="tt-border-block">
          <?php if($title): ?>
          <div class="tt-title-block type-2">
            <h3 class="tt-title-text"><?php echo esc_html($title); ?></h3>
          </div>
          <div class="empty-space marg-lg-b15"></div>
          <?php endif; ?>

          <div class="tt-about">
            <?php if(isset($instance['url'])): ?>
            <a class="custom-hover img-border" href="#">
              <img class="img-responsive" src="<?php echo esc_url($instance['url']); ?>" height="195" width="331" alt="">
            </a>
            <?php endif; ?>
            <?php if(isset($instance['content'])): ?>
            <div class="simple-text">
              <p><?php echo esc_html($instance['content']); ?></p>
            </div>
            <?php endif; ?>
            <?php if(isset($instance['signature'])): ?>
              <img class="img-responsive center-block" src="<?php echo esc_url($instance['signature']); ?>" height="67" width="104" alt="">
            <?php endif; ?>
          </div>
        </div>

        <?php echo $after_widget;
        $cache[$args['widget_id']] = ob_get_flush();
        wp_cache_set('widget_about_us_entries', $cache, 'widget');
    }

    function update( $new_instance, $old_instance )
    {
      $instance              = $old_instance;
      $instance['title']     = strip_tags($new_instance['title']);
      $instance['url']       = $new_instance['url'];
      $instance['content']   = $new_instance['content'];
      $instance['signature'] = $new_instance['signature'];
      $instance['link']      = $new_instance['link'];
      $this->flush_widget_cache();

      $alloptions = wp_cache_get( 'alloptions', 'options' );
      if ( isset($alloptions['widget_about_us_entries']) )
      {
          delete_option('widget_about_us_entries');
      }
      return $instance;
    }

    function flush_widget_cache()
    {
      wp_cache_delete('widget_about_us_entries', 'widget');
    }

    function form( $instance )
    {
        $title     = isset($instance['title']) ? $instance['title'] : '';
        $url       = isset($instance['url']) ? $instance['url'] : '';
        $content   = isset($instance['content']) ? $instance['content'] : '';
        $signature = isset($instance['signature']) ? $instance['signature'] : '';
        $link      = isset($instance['link']) ? $instance['link'] : '#';
        ?>
        <p><label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php _e( 'Title:', 'videoly-addons' ); ?></label>
        <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" /></p>

        <p><label for="<?php echo esc_attr($this->get_field_id( 'url' )); ?>"><?php esc_html_e('Image URL:','videoly-addons'); ?> <input class="widefat" id="<?php echo esc_attr($this->get_field_id( 'url' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'url' )); ?>" type="text" value="<?php echo esc_attr($url); ?>" /></label></p>

         <p><label for="<?php echo esc_attr($this->get_field_id( 'content' )); ?>"><?php esc_html_e('Content:','videoly-addons'); ?> <textarea class="widefat" rows="7" id="<?php echo esc_attr($this->get_field_id('content')); ?>" name="<?php echo esc_attr($this->get_field_name('content')); ?>"><?php echo esc_textarea($content); ?></textarea></label></p>

         <p><label for="<?php echo esc_attr($this->get_field_id( 'signature' )); ?>"><?php esc_html_e('Signature Image URL:','videoly-addons'); ?> <input class="widefat" id="<?php echo esc_attr($this->get_field_id( 'signature' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'signature' )); ?>" type="text" value="<?php echo esc_attr($signature); ?>" /></label></p>

        <p><label for="<?php echo esc_attr($this->get_field_id( 'link' )); ?>"><?php esc_html_e('Link URL:','videoly-addons'); ?> <input class="widefat" id="<?php echo esc_attr($this->get_field_id( 'link' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'link' )); ?>" type="text" value="<?php echo esc_attr($link); ?>" /></label></p>
        <?php
    }
}
