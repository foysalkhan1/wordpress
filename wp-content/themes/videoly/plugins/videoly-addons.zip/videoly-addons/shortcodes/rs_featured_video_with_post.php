<?php
/**
 *
 * RS Image Block
 * @since 1.0.0
 * @version 1.0.0
 *
 *
 */
function rs_featured_video_with_post( $atts, $content = '', $id = '' ) {

  extract( shortcode_atts( array(
    'id'        => '',
    'class'     => '',
    'video_url' => '',
    'cats'      => 0,
    'style'     => 'style1',
    'heading'   => '',
    'orderby'   => 'ID'
  ), $atts ) );

  $id     = ( $id ) ? ' id="'. esc_attr($id) .'"' : '';
  $class  = ( $class ) ? ' '. videoly_sanitize_html_classes($class) : '';
  $posts_per_page = ($style == 'style1') ? 4 : 2;
  $output = '';

  $args = array(
    'orderby'        => $orderby,
    'posts_per_page' => $posts_per_page,
  );

  if( $cats ) {
    $args['tax_query'] = array(
      array(
        'taxonomy' => 'category',
        'field'    => 'ids',
        'terms'    => explode( ',', $cats )
      )
    );
  }

  ob_start();

  $the_query = new WP_Query($args); 
  switch ($style) {
    case 'style1': 
    default: ?>
    <div class="row">
      <div class="col-md-9 center-block float-none">
        <div class="tt-featured-video-with-post">

            <?php if(!empty($heading)): ?>
            <div class="tt-title-block">
              <h3 class="tt-title-text"><?php echo esc_html($heading); ?></h3></div><div class="empty-space  marg-lg-b25">
            </div>
            <?php endif; ?>

          <?php if(!empty($video_url)): ?>
          <div class="embed-responsive embed-responsive-16by9">
            <iframe class="embed-responsive-item" src="<?php echo esc_url($video_url); ?>"></iframe>
          </div>
          <div class="empty-space marg-lg-b30 marg-sm-b15"></div>
          <?php endif; ?>


          <div class="row">
            <?php while ($the_query -> have_posts()) : $the_query -> the_post(); ?>
            <div class="col-md-3 col-sm-6">
              <div <?php post_class('tt-post type-9'); ?>>
                <?php videoly_post_format('videoly-medium-alt', 'img-responsive'); ?>
                <div class="tt-post-info">
                  <?php videoly_blog_title('c-h6'); ?>
                  <?php videoly_blog_author_date(); ?>
                </div>
              </div>
            </div>
            <div class="empty-space marg-sm-b15"></div>
            <?php endwhile; wp_reset_postdata(); ?>
          </div>


        </div>
      </div>
    </div>
    <?php
    break;
    case 'style2': ?>

    <div class="row">
      <div class="col-md-9 center-block float-none">
        <div class="tt-featured-video-with-post">

            <?php if(!empty($heading)): ?>
            <div class="tt-title-block">
              <h3 class="tt-title-text"><?php echo esc_html($heading); ?></h3></div><div class="empty-space  marg-lg-b25">
            </div>
            <?php endif; ?>

          
          <div class="row">  
            <?php if(!empty($video_url)): ?>
            <div class="col-md-9">
              <div class="embed-responsive embed-responsive-16by9">
                <iframe class="embed-responsive-item" src="<?php echo esc_url($video_url); ?>"></iframe>
              </div>
              <div class="empty-space marg-xs-b15"></div>
            </div>
            <?php endif; ?>
            <div class="col-md-3 col-sm-6">
              <?php while ($the_query -> have_posts()) : $the_query -> the_post(); ?>
              <div <?php post_class('tt-post type-9'); ?>>
                <?php videoly_post_format('videoly-medium-alt', 'img-responsive'); ?>
                <div class="tt-post-info">
                  <?php videoly_blog_title('c-h6'); ?>
                  <?php videoly_blog_author_date(); ?>
                </div>
              </div>
              <div class="empty-space marg-lg-b10 marg-sm-b5"></div>
              <?php endwhile; wp_reset_postdata(); ?>
            </div>
          </div>
        </div>
      </div>
    </div>


    <?php break;
  }


  $output = ob_get_clean();
  return $output;

}

add_shortcode('rs_featured_video_with_post', 'rs_featured_video_with_post');
