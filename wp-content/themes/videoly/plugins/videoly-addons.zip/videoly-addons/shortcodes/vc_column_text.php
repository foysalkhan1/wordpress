<?php
/**
 *
 * VC Column Text
 * @since 1.0.0
 * @version 1.0.0
 *
 */
function vc_column_text( $atts, $content = '', $id = '' ){

  extract( shortcode_atts( array(
    'id'              => '',
    'class'           => '',
    'font_size'       => '',
    'font_color'      => '',
    'letter_spacing'  => '',
    'line_height'     => '',
    'wrap_with_class' => 'yes',
  ), $atts ) );

  $id        = ( $id ) ? ' id="'. esc_attr($id) .'"' : '';
  $class     = ( $class ) ? ' '. videoly_sanitize_html_classes($class) : '';
  $customize = ($font_color || $line_height || $font_size || $letter_spacing) ? true:false;
  
  $output       = '';
  $uniqid_class = '';

  if( $customize ) {

    $uniqid       = time().'-'.mt_rand();
    $custom_style = '';

    $custom_style .=  '.custom-font-properties-'.$uniqid.'{';
    $custom_style .=  ($font_size) ? 'font-size:'.$font_size.';':'';
    $custom_style .=  ($line_height) ? 'line-height:'.$line_height.';':'';
    $custom_style .=  ($font_color) ? 'color:'.$font_color.' !important;':'';
    $custom_style .=  ($letter_spacing) ? 'letter-spacing:'.$letter_spacing.';':'';

    $custom_style .= '}';

    videoly_add_inline_style( $custom_style );

    $uniqid_class = ' custom-font-properties-'. $uniqid;

  }


  $output .= ($wrap_with_class == 'yes') ? '<div class="text-block'.$class.'" '.$id.'>':'';
  $output .= ($wrap_with_class == 'yes') ? '<div class="simple-text'.$uniqid_class.'">':'';
  $output .= rs_set_wpautop($content);
  $output .=  ($wrap_with_class == 'yes') ? '</div></div>':'';

  return $output;
}
add_shortcode( 'vc_column_text', 'vc_column_text');

