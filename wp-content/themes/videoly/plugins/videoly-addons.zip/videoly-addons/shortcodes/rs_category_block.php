<?php
/**
 *
 * RS Space
 * @since 1.0.0
 * @version 1.0.0
 *
 */
function rs_category_block( $atts, $content = '', $id = '' ) {

  extract( shortcode_atts( array(
    'id'    => '',
    'class' => '',
    'cats'  => '',
    'image' => ''
  ), $atts ) );

  $id    = ( $id ) ? ' id="'. esc_attr($id) .'"' : '';
  $class = ( $class ) ? ' '. videoly_sanitize_html_classes($class) : ''; 

  $output  = '';
  if(is_numeric($cats) && is_numeric($image) && !empty($image)):
    $image_src = wp_get_attachment_image_src( $image, 'videoly-big-alt' );
    $output .=  '<div '.$id.' class="tt-category-block'.$class.'">';
    $output .=  '<a href="'.get_category_link($cats).'">';
    if(isset($image_src[0])):
      $output .=  '<div class="tt-category-img custom-hover">';
      $output .=  '<img class="img-responwsive" src="'.esc_url($image_src[0]).'" alt="">';
      $output .=  '</div>';
    endif;
    $output .=  '<div class="tt-category-text">';
    $output .= '<h5 class="tt-category-title c-h5">'.get_cat_name($cats).'</h5>';
    $output .=  '</div>';
    $output .=  '</a></div>';
    $output .=  '<div class="empty-space marg-xs-b15"></div>';
  endif;

  return $output;
}

add_shortcode('rs_category_block', 'rs_category_block');
