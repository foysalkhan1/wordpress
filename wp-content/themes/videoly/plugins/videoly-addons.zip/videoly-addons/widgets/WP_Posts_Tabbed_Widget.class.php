<?php
/**
 * Latest posts widget
 *
 * @package videoly
 */
class videoly_WP_Posts_Tabbed_Widget extends WP_Widget
{
  function __construct()
  {
    $widget_ops = array('classname' => 'widget_posts_tabbed_entries', 'description' => esc_html__( 'Tabbed Post', 'videoly-addons' ) );
    parent::__construct('tabbed-posts', esc_html__( '- videoly: Tabbed Posts', 'videoly-addons' ), $widget_ops);

    $this-> alt_option_name = 'widget_posts_tabbed_entries';

  }

  function widget($args, $instance)
  {
    global $post;

    $cache = wp_cache_get('widget_posts_tabbed_entries', 'widget');

    if ( !is_array($cache) )
    {
      $cache = array();
    }
    if ( ! isset( $args['widget_id'] ) )
    {
      $args['widget_id'] = $this->id;
    }

    if ( isset( $cache[ $args['widget_id'] ] ) )
    {
      echo $cache[ $args['widget_id'] ];
      return;
    }

    ob_start();
    extract($args);
    echo $before_widget;
    $title = apply_filters('widget_title', empty($instance['title']) ? esc_html__( 'Popular Posts', 'videoly-addons' ) : $instance['title'], $instance, $this->id_base);
    if ( empty( $instance['number'] ) || ! $number = absint( $instance['number'] ) ) {
      $number = 4;
    }

    ?>


    <div class="tt-tab-wrapper type-1 clearfix">
      <div class="tt-tab-nav-wrapper">                            
        <div  class="tt-nav-tab">
          <div class="tt-nav-tab-item active"><i class="fa fa-bolt" aria-hidden="true"></i><?php echo esc_html__('Trending', 'videoly-addons'); ?></div>
          <div class="tt-nav-tab-item"><i class="fa fa-heart" aria-hidden="true"></i><?php echo esc_html__('Popular', 'videoly-addons'); ?></div>        
        </div>
      </div>
      <div class="tt-tabs-content clearfix">
        <div class="tt-tab-info active">
          <ul class="tt-post-list">
            <?php echo videoly_post_query('date', $number); ?>                                                    
          </ul>
          <a class="c-btn type-2" href="<?php echo esc_url(home_url('/' )); ?>"><?php echo esc_html__('Show More', 'videoly-addons'); ?></a>
        </div>
        <div class="tt-tab-info">
          <ul class="tt-post-list">
            <?php echo videoly_post_query('meta_value_num', $number, 'post_views_count'); ?>
          </ul>
          <a class="c-btn type-2" href="<?php echo esc_url(home_url('/' )); ?>"><?php echo esc_html__('Show More', 'videoly-addons'); ?></a>                                    
        </div>               
      </div>
    </div>

  <?php
    echo $after_widget;
    $cache[$args['widget_id']] = ob_get_flush();
    wp_cache_set('widget_posts_tabbed_entries', $cache, 'widget');
  }

  function update( $new_instance, $old_instance ) {
    $instance = $old_instance;
    $instance['title'] = strip_tags($new_instance['title']);
    $instance['number'] = (int) $new_instance['number'];

    $alloptions = wp_cache_get( 'alloptions', 'options' );
    if ( isset($alloptions['widget_posts_tabbed_entries']) )
    {
      delete_option('widget_posts_tabbed_entries');
    }
    return $instance;
  }

  function form( $instance ) {
    $title = isset($instance['title']) ? $instance['title'] : '';
    $number = isset($instance['number']) ? $instance['number'] : 4;
    ?>
    <p><label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php _e( 'Title:', 'videoly-addons' ); ?></label>
    <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>" /></p>

    <p><label for="<?php echo esc_attr($this->get_field_id('number')); ?>"><?php _e( 'Number of posts to show:', 'videoly-addons' ); ?></label>
    <input id="<?php echo esc_attr($this->get_field_id('number')); ?>" name="<?php echo esc_attr($this->get_field_name('number')); ?>" type="text" value="<?php echo esc_attr($number); ?>" size="3" /></p>
    <?php
  }
}


function videoly_post_query($order_by, $post_per_page, $meta_key = '') {

  global $post;
  $latest = get_posts(
    array(
      'suppress_filters'    => false,
      'ignore_sticky_posts' => 1,
      'orderby'             => $order_by,
      'order'               => 'desc',
      'meta_key'            => $meta_key,
      'numberposts'         => $post_per_page,
      'meta_query'          => array(array('key' => '_thumbnail_id')), 
    )
  );

  ob_start();

  foreach($latest as $post) :
    setup_postdata($post);
  ?>

  <li>
    <div <?php post_class('tt-post type-7 clearfix'); ?>>
      <?php videoly_post_format('videoly-small-alt', 'img-responsive'); ?>
      <div class="tt-post-info">
        <?php videoly_blog_title('c-h6'); ?>
        <?php videoly_blog_category(); ?>
      </div>
    </div>                                            
  </li>

  <?php endforeach;
  $contents = ob_get_contents();
  ob_end_clean();
  return $contents;

}