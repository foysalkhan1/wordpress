<?php
/**
 *
 * RS Blog
 * @since 1.0.0
 * @version 1.1.0
 *
 */
function rs_featured_blog( $atts, $content = '', $id = '' ) {

  extract( shortcode_atts( array(
    'id'            => '',
    'class'         => '',
    'cats'          => 0,
    'style'         => 'style1',
    'orderby'       => 'ID',
    'post_per_page' => '3',
    'exclude_posts' => '',
  ), $atts ) );

  $id    = ( $id ) ? ' id="'. esc_attr($id) .'"' : '';
  $class = ( $class ) ? ' '. $class : '';

  if (get_query_var('paged')) {
    $paged = get_query_var('paged');
  } elseif (get_query_var('page')) {
    $paged = get_query_var('page');
  } else {
    $paged = 1;
  }

  $args = array(
    'paged'          => $paged,
    'orderby'        => $orderby,
    'posts_per_page' => $post_per_page,
  );

  if( $cats ) {
    $args['tax_query'] = array(
      array(
        'taxonomy' => 'category',
        'field'    => 'ids',
        'terms'    => explode( ',', $cats )
      )
    );
  }


  if (!empty($exclude_posts)) {
    $exclude_posts_arr = explode(',',$exclude_posts);
    if (is_array($exclude_posts_arr) && count($exclude_posts_arr) > 0) {
      $args['post__not_in'] = array_map('intval',$exclude_posts_arr);
    }
  }

  ob_start();

  $the_query = new WP_Query($args);

  //echo $style;
  switch ($style) {
    case 'style1': ?>
      <div <?php echo esc_attr($id); ?> class="row <?php echo esc_attr($class); ?>">
      <?php $i = 0;
        while ($the_query -> have_posts()) : $the_query -> the_post(); 
          if($i == 0): ?>
            <div <?php post_class('col-sm-12'); ?>>
              <div class="tt-post">
                <?php videoly_post_format('videoly-big', 'img-responsive'); ?>

                <div class="tt-post-info">
                  <?php videoly_blog_category(); ?>
                  <?php videoly_blog_title(); ?>
                  <?php videoly_blog_author_date(); ?>
                  <?php videoly_blog_excerpt(30); ?>
                  <?php videoly_blog_post_bottom(); ?>
                </div>
              </div>
              <div class="empty-space marg-lg-b30"></div>
            </div>
          <?php else: ?>
            <div <?php post_class('col-sm-6'); ?>>
              <div class="tt-post type-2">
                  <?php videoly_post_format('videoly-medium', 'img-responsive'); ?>
                  <div class="tt-post-info">
                    <?php videoly_blog_category(); ?>
                    <?php videoly_blog_title('c-h5'); ?>
                    <?php videoly_blog_author_date(); ?>
                    <?php videoly_blog_excerpt(15); ?>
                    <?php videoly_blog_post_bottom(); ?>
                  </div>
              </div>
              <div class="empty-space marg-xs-b30"></div>          
            </div>                    
            <div class="empty-space marg-lg-b55 marg-sm-b30"></div>
          <?php
          endif;
          $i++;
        endwhile;
        wp_reset_postdata(); ?>
      </div>
      <?php
      break;
    case 'style2':
    default: ?>

      <div <?php echo esc_attr($id); ?> class="row <?php echo esc_attr($class); ?>">
        <?php $i = 0; while ($the_query -> have_posts()) : $the_query -> the_post(); ?>
        <?php if($i == 0): ?>
        <div <?php post_class('col-sm-8'); ?>>

          <div class="tt-post type-2">
            <?php videoly_post_format('videoly-big-alt-2', 'img-responsive'); ?>
            <div class="tt-post-info">
              <?php videoly_blog_category(); ?>
              <?php videoly_blog_title('c-h5'); ?>
              <?php videoly_blog_author_date(); ?>
              <?php videoly_blog_excerpt(); ?>
              <?php videoly_blog_post_bottom(); ?>
            </div>
          </div>
          <div class="empty-space marg-xs-b30"></div> 
        </div>
        <?php else: ?>

        <div <?php post_class('col-sm-4'); ?>>
          <div class="tt-post type-4">
            <?php videoly_post_format('videoly-medium', 'img-responsive'); ?>
            <div class="tt-post-info">
              <?php videoly_blog_title('c-h5'); ?>
              <?php videoly_blog_author_date(); ?>
            </div>
          </div>
          <?php echo (($the_query->current_post + 1) !== ( $the_query->post_count )) ? '<div class="empty-space marg-lg-b25"></div>':''; ?>
        </div>
        <?php endif; $i++; ?>
        <?php endwhile;
        wp_reset_postdata(); ?>
      </div>
      <?php
        
      break;
  }

  $output = ob_get_clean();
  return $output;
}
add_shortcode( 'rs_featured_blog', 'rs_featured_blog' );
