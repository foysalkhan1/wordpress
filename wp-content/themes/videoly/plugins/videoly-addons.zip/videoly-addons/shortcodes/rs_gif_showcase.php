<?php
/**
 *
 * RS Image Block
 * @since 1.0.0
 * @version 1.0.0
 *
 *
 */
function rs_gif_showcase( $atts, $content = '', $id = '' ) {

  extract( shortcode_atts( array(
    'id'      => '',
    'class'   => '',
    'gif_url' => ''
  ), $atts ) );

  $id     = ( $id ) ? ' id="'. esc_attr($id) .'"' : '';
  $class  = ( $class ) ? ' '. videoly_sanitize_html_classes($class) : '';
  $output = '';

  if(!empty($gif_url)){
    $output .=  '<div '.$id.' class="gif-showcase'.$class.'">';
    $output .=  '<iframe class="giphy-embed" src="'.esc_url($gif_url).'"></iframe>';
    $output .=  '</div>';
  }

  return $output;
}

add_shortcode('rs_gif_showcase', 'rs_gif_showcase');
