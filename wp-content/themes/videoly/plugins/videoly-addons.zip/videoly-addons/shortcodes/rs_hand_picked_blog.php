<?php
/**
 *
 * RS Blog
 * @since 1.0.0
 * @version 1.1.0
 *
 */
function rs_hand_picked_blog( $atts, $content = '', $id = '' ) {

  extract( shortcode_atts( array(
    'id'            => '',
    'class'         => '',
    'cats'          => '',
    'orderby'       => 'ID',
    'post_per_page' => '8',
    'style'         => 'style1',
    'exclude_posts' => '',
  ), $atts ) );

  $id    = ( $id ) ? ' id="'. esc_attr($id) .'"' : '';
  $class = ( $class ) ? ' '. $class : '';

  if (get_query_var('paged')) {
    $paged = get_query_var('paged');
  } elseif (get_query_var('page')) {
    $paged = get_query_var('page');
  } else {
    $paged = 1;
  }

  $layout = videoly_get_opt('main-layout');
  switch ($layout) {
    case 'right_sidebar':
    case 'left_sidebar':
      $col_big   = 'col-sm-6';
      $col_small = 'col-xs-6 col-sm-4 col-lg-3';
      break;

    default:
      $col_big   = 'col-sm-4';
      $col_small = 'col-xs-6 col-sm-4 col-lg-2';
      # code...
      break;
  }

  $args = array(
    'paged'          => $paged,
    'orderby'        => $orderby,
    'posts_per_page' => $post_per_page,
    'order'          => 'ASC',
  );

  if( $cats ) {
    $args['tax_query'] = array(
      array(
        'taxonomy' => 'category',
        'field'    => 'ids',
        'terms'    => explode( ',', $cats )
      )
    );
  }

  if (!empty($exclude_posts)) {
    $exclude_posts_arr = explode(',',$exclude_posts);
    if (is_array($exclude_posts_arr) && count($exclude_posts_arr) > 0) {
      $args['post__not_in'] = array_map('intval',$exclude_posts_arr);
    }
  }

  ob_start();

  $the_query = new WP_Query($args);

  switch ($style) {
    case 'style1': ?>
      <div class="row">
        <div class="post-grid-view">
        <?php $i = 0; while ($the_query -> have_posts()) : $the_query -> the_post(); ?>
          <?php echo videoly_post_grid($col_small); ?>
        <?php $i++; endwhile; wp_reset_postdata(); ?>
        </div>
      </div>
      <?php
      # code...
      break;

    case 'style2':
    case 'style3':
    default: ?>
      <div class="row">
        <div class="post-grid-view">
        <?php
          $col_big = ($style == 'style3') ? 'col-sm-6':$col_big;
          $i = 0; while ($the_query -> have_posts()) : $the_query -> the_post();
          if($i == 0):
        ?>
          <div <?php post_class($col_big); ?>>

            <div class="tt-post type-2">
              <?php videoly_post_format('videoly-big-alt-2', 'img-responsive'); ?>
              <div class="tt-post-info">
                <?php videoly_blog_category(); ?>
                <?php videoly_blog_title('c-h5'); ?>
                <?php videoly_blog_author_date(); ?>
                <?php videoly_blog_excerpt(); ?>
                <?php videoly_blog_post_bottom(); ?>
              </div>
            </div>
            <div class="empty-space marg-xs-b30"></div>
          </div>
        <?php else:
          echo videoly_post_grid($col_small);
          endif;
          $i++; endwhile; wp_reset_postdata();
        ?>
        </div>
      </div>
      <?php
      # code...
      break;
  }

  ?>


  <?php
  $output = ob_get_clean();
  return $output;
}
add_shortcode( 'rs_hand_picked_blog', 'rs_hand_picked_blog' );
